package Connector;

import java.sql.Connection;

public interface IDBConnector {

    public Connection getMyConnection();

}
